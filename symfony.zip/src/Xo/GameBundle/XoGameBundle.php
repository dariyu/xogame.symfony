<?php

namespace Xo\GameBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class XoGameBundle extends Bundle
{
}
